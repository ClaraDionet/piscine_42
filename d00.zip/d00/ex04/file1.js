function unicorn()
{
	puffin()
}

